<form action="Baiviet.php" method="post" class="container-sm" style="margin-top: 10px;">
	<div cols="60" rows="10">
		<input type="text" name="title-Post" placeholder="Tên tiêu đề">
		<input type="text" name="anhbaiviet" placeholder="Link Anh">
	</div>
	<textarea name="content-Post" cols="60" rows="10" style="margin-top: 10px;" placeholder="bai viet cua ban"></textarea>
	<br>
	<input cols="10" rows="10" type="text" name="authorPost" placeholder="Tên tác giả ">
	<input type="submit" name="Dangbai" value="Dangbai" style="margin-top: 10px;">
</form>
<?php 
require "header.php";
require "slideword.php";
require "../Controller/loginC.php";
if (isset($_SESSION["UserName"]) && isset($_SESSION["Passwords"])) {
	echo $_SESSION["UserName"];
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php require "Link.php"; ?>
</head>
<body>
	<div class="container-sm">
		<h5 style="color: red">Login/ Đăng Nhập </h5>
		<form action="Login.php" method="post">
			<div class="px-4 py-3">
				<label>UserName</label>
				<input type="text" name="UserName">
			</div>
			<div class="px-4 py-3">
				<label>Password</label>
				<input type="password" name="Passwords">
			</div>
			<button name="login" style="margin-top: 10px;color: red;background-color: lightblue">
				Login /Đăng Nhập 
			</button>
		</form>
		<h5 style="color: red;margin-top: 10px;">Sign Up / Đăng Ký </h5>
		<form action="Login.php" method="post" style="display: flex;margin-top: 20px">
			<div class="px-4 py-3">
				<label>UserName</label>
				<br>
				<input type="text" name="userName">
				<br>
				<label>Password</label>
				<br>
				<input type="password" name="password">
				<br>
				<label>Full Name</label>
				<br>
				<input type="text" name="fullname">
				<br>
				<label>Age</label>
				<br>
				<input type="text" name="age">
				<br>
			</div>
			<div class="px-4 py-3">
				<label>Address</label>
				<br>
				<input type="text" name="address">
				<br>
				<label>Phone</label>
				<br>
				<input type="text" name="phone">
				<br>
				<label>Email</label>
				<br>
				<input type="text" name="email">
				<br>
				<b name="check"></b>
				<br>
				<button name="signup" style="margin-top: 10px;color: red;background-color: lightblue">
					Sign up/ Đăng Ký 
				</button>
			</div>
		</form>
	</div>
	<a href="login.php" class="btn btn-light" name="logout" style="margin-top: 10px;">
		Log out(Đăng Xuất)
	</a>
	<?php require "date.php"; ?>
</body>
</html>
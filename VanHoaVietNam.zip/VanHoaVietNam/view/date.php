<div style="display: flex;justify-content: space-between;" class="container-sm">
	<div style="color: red">
		<i>Dân ta phải biết sử ta,cho tường gốc tích nước nhà Việt Nam</i>
	</div>
	<div style="color: red">
		<?php
		date_default_timezone_set("Asia/Ho_Chi_Minh");
		echo "VietNam: " . date("Y-m-d H:i:s") . "<br>";
		?>
	</div>
</div>
<?php 
require "header.php";
require "slideword.php";
require "../Controller/loginC.php";
if (isset($_SESSION["UserName"]) && isset($_SESSION["Passwords"])) {
	echo $_SESSION["UserName"];
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php require "Link.php"; ?>
</head>
<body>
	<?php for ($i = 0; $i < count($mangusers); $i++) {  ?>
		<div class="container-sm" class="display">
			<form action="Lienhe.php" method="post" style="margin-top: 10px;">
				<p style="color: red">Lien he voi <?php echo $mangusers[$i]->fullname; ?></p>
				<i>Name is: <?php echo $mangusers[$i]->fullname; ?></i>
				<br>
				<i>Age is:<?php echo $mangusers[$i]->age; ?></i>
				<br>
				<i>Address is:<?php echo $mangusers[$i]->address; ?></i>
				<br>
				<i>Phone is: <?php echo $mangusers[$i]->phone; ?></i>
				<br>
				<i>Email is: <?php echo $mangusers[$i]->email; ?></i>
			</form>
		</div>
	<?php } ?>
	<?php require "date.php"; ?>
</body>
</html>
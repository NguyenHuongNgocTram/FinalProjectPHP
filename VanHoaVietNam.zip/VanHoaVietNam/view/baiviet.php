<?php 
require "header.php";
require "slideword.php";
require "../Controller/loginC.php";
if (isset($_SESSION["UserName"]) && isset($_SESSION["Passwords"])) {
	echo $_SESSION["UserName"];
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php require "Link.php"; ?>
</head>
<body>
	<?php require "../Controller/postblog.php" ?>
	<?php require "postbai.php" ?>
	<div class="container-sm">
		<p style="color: red;margin-top: 5px;font-size: 25px">Articles / Bài viết</p>
		<form action="view.php" method="post" class="display" class="container-sm">
			<?php for ($i = 0; $i < count($arrPosts); $i++) { ?>
				<button style="width: 300; height: 200;margin-top: 5px" class="container-sm" name="view" value="<?php echo $arrPosts[$i]->idPost; ?>">
					<img src="<?php echo $arrPosts[$i]->image ?>" width="200" height="150">
					<h5>
						<?php echo $arrPosts[$i]->titleContent; ?>
					</h5>
				</button>
			<?php } ?>
		</form>
	</div>
	<?php require "date.php"; ?>
</body>
</html>
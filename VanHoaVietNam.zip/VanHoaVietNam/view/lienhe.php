<?php 
require "header.php";
require "slideword.php";
require "../Controller/loginC.php";
if (isset($_SESSION["UserName"]) && isset($_SESSION["Passwords"])) {
	echo $_SESSION["UserName"];
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php require "Link.php"; ?>
</head>
<body>
<?php require "date.php"; ?>
</body>
</html>
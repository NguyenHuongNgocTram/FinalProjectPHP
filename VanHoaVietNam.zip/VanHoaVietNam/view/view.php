<?php 
require "header.php";
require "slideword.php";
require "../Controller/postblog.php";
require "../Controller/loginC.php";
if (isset($_SESSION["UserName"]) && isset($_SESSION["Passwords"])) {
	echo $_SESSION["UserName"];
}
$sql = "SELECT * FROM baiviet where idPost=".$_SESSION["view"];
$id = $_SESSION["id"];
$resuilt = $db->query($sql)->fetch_all();

if (isset($_POST["delete"])) {
	$_SESSION["delete"] = $_POST["delete"];
	$sql = "DELETE FROM baiviet where idPost=".$_SESSION["view"];
	$db->query($sql);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php require "Link.php";?>
</head>
<body>
	<div class="container-sm">
		<h3><?php echo $arrPosts[$id]->titleContent; ?></h3>
		<img src="<?php echo $arrPosts[$id]->image; ?>" width="400" height="300">
		<p><?php echo $arrPosts[$id]->content; ?></p>
		<i><?php echo $arrPosts[$id]->author; ?></i>
		<input type="submit" name="accept" value="accept" style="margin-top: 10px;">
		<input type="submit" name="accept" value="delete" style="margin-top: 10px;">
	</div>
	<?php require "date.php"; ?>
</body>
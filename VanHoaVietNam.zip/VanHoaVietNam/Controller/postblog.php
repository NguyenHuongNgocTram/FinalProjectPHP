<?php 
	require "../model/database.php";
	require "../model/Baiviet.php";
	$sql = "SELECT * FROM baiviet";
	session_start();
	$result = $db->query($sql)->fetch_all();
	$arrPosts=[];
	for ($i=0; $i <count($result); $i++) { 
		$posts[$i] = new postcontents($result[$i][0],$result[$i][1],$result[$i][2],$result[$i][3],$result[$i][4],$result[$i][5],$result[$i][6]);
		array_push($arrPosts,$posts[$i]);
	}
	if(isset($_POST["Dangbai"])){
		$image= $_POST["anhbaiviet"];
		$titleContent = $_POST["title-Post"];
		$content = $_POST["content-Post"];
		$author = $_POST["authorPost"];
		date_default_timezone_set("Asia/Ho_Chi_Minh");
		$datePost = "VietNam: " . date("Y-m-d H:i:s");
		if ($image==null||$titleContent==null|| $content== null || $author==null) {
			echo "Cập nhập không thành công, bạn phải nhập đầy đủ các thông tin";
		}else{
			$sql="INSERT INTO baiviet VALUES (null,"."'".$image."'".","."'".$titleContent."'".","."'".$content."'".","."'".$author."'".","."'"."false"."'".","."'".$datePost."'".");";
			$db->query($sql);
			echo $sql;
		}
	}
	if (isset($_POST["view"])) {
		$_SESSION["view"]=$_POST["view"];
		for ($i=0; $i < count($result); $i++) { 
			if($_SESSION["view"]==$result[$i][0]){
				$_SESSION["id"]= $i;
				header("location:view.php");
			}
		}
	}
?>
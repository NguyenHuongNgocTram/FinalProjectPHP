<?php
	require "../model/database.php";
	require "../model/user.php";
	$sql = "SELECT * FROM nguoidung"; 
	$resuilt = $db->query($sql)->fetch_all();
	$mangusers=[];
	for ($i=0; $i <count($resuilt); $i++) { 
		$members[$i] = new user($resuilt[$i][0],$resuilt[$i][1],$resuilt[$i][2],$resuilt[$i][3],$resuilt[$i][4],$resuilt[$i][5],$resuilt[$i][6],$resuilt[$i][7],$resuilt[$i][8]);
		array_push($mangusers,$members[$i]);
	}
	if(isset($_POST["login"])){
		$_SESSION["UserName"]=$_POST["UserName"];
		$_SESSION["Passwords"]=$_POST["Passwords"];
		for ($i=0; $i < count($resuilt) ; $i++) { 
			if ($_SESSION["UserName"] == $resuilt[$i][1] && $_SESSION["Passwords"] == $resuilt[$i][2]) {
				header("location:home.php");
				echo "Đăng nhập thành công";
				die();
			}
		}
		echo "Vui Lòng Thử Lại!!!!";
	}
	if(isset($_POST["signup"])){
		$userName=$_POST["userName"];
		$passwords=$_POST["password"];
		$fullname=$_POST["fullname"];
		$age=$_POST["age"];
		$address=$_POST["address"];
		$phone=$_POST["phone"];
		$email=$_POST["email"];
		$role="noadmin";
		if ($userName==null||$passwords==null||$fullname==null||$age==null||$address==null||$phone==null||$email==null) {
			echo "Đăng ký không thành công, bạn phải nhập đầy đủ các thông tin";
		}else{
			$sql="INSERT INTO nguoidung VALUES (null,"."'".$userName."'".","."'".$passwords."'".","."'".$fullname."'".",".$age.","."'".$address."'".","."'".$phone."'".","."'".$email."'".","."'".$role."'".");";
			$db->query($sql);
			echo "Đăng Ký thành công vui lòng đang nhập để vào web";
		}	
	}
?>
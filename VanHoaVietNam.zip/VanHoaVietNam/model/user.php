<?php 
	class user{
		public $idCode;
		public $userName;
		public $password;
		public $fullname;
		public $age;
		public $address;
		public $phone;
		public $email;
		public $role;
		function __construct($idCode,$userName,$password,$fullname,$age,$address,$phone,$email,$role){
			$this->idCode=$idCode;
			$this->userName=$userName;
			$this->password=$password;
			$this->fullname=$fullname;
			$this->age=$age;
			$this->address=$address;
			$this->phone=$phone;
			$this->email=$email;
			$this->role=$role;
		}
	}
?>
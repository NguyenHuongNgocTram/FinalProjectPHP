<?php
	$server = "localhost";
	$user = "root";
	$pwd = "";
	$dbName = "cultureofvietnamese";
	$db = new mysqli($server, $user, $pwd, $dbName);  
?>
<?php  
	class postcontents{
		public $idPost;
		public $image;
		public $titleContent;
		public $content;
		public $author;
		public $accept;
		public $datePost;
		function __construct($idPost,$image,$titleContent,$content,$author,$accept,$datePost)
		{
			$this->idPost=$idPost;
			$this->image=$image;
			$this->titleContent=$titleContent;
			$this->content=$content;
			$this->author=$author;
			$this->accept=$accept;
			$this->datePost=$datePost;
		}
	} 
?>